let person = new Object();
person["firstName"] = "Rohik";
person["lastName"] = "Galli";
person.Address = new Object();
person.Address.street = "jaihind Enclave";
person.Address.city = "Hyderabad";
person.Address.state = "Telangana";
console.log(person);
