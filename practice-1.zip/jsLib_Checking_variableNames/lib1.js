window.libraryName = window.libraryName || "Lib 1";
console.log("Lib 1 is loaded");
