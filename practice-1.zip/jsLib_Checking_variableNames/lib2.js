window.libraryName = window.libraryName || "Lib 2";
console.log("Lib 2 is loaded");
